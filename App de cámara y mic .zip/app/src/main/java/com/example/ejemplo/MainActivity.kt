package com.example.ejemplo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val myButton2: Button = findViewById(R.id.mcf)
        val myButton: Button = findViewById(R.id.btnPhoto)
        myButton.setOnClickListener {
            // Primero, ejecutamos la acción del primer OnClickListener
            Toast.makeText(this, "¡Botón clickeado!", Toast.LENGTH_SHORT).show()
            Toast.makeText(this,"Boton de microfono clickeado",Toast.LENGTH_SHORT).show()

            // Luego, ejecutamos la verificación de permisos
            checkPermission()
        }
        myButton2.setOnClickListener {
            // Primero, ejecutamos la acción del segundo OnClickListener
            Toast.makeText(this, "¡Botón de micrófono clickeado!", Toast.LENGTH_SHORT).show()

            // Luego, ejecutamos la verificación de permisos
            checkMicrophonePermission()
        }
        }

    private fun checkPermission() {
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            //permiso no aceptado por ahora
            requestCamaraPermssion()
        }else{
            //Abrir camara
            openCamera()
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivity(intent)
    }
    private fun openMic(){
        val intent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
        startActivity(intent)
    }

    private fun requestCamaraPermssion() {
        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.CAMERA)){
            //el ususario ya rechazado los perisos
            Toast.makeText(this,"Prmisos rechazados",Toast.LENGTH_SHORT).show()

        }else{
            //pedir permisos
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA),777)
        }
    }
    private fun checkMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // Permiso no aceptado por ahora
            requestMicrophonePermission()
        } else {
            // Acción para cuando se concede el permiso del micrófono
            openMic()
        }
    }
    private fun requestMicrophonePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
            // El usuario ya rechazó los permisos del micrófono
            Toast.makeText(this, "Permiso de micrófono rechazado", Toast.LENGTH_SHORT).show()
        } else {
            // Pedir permisos del micrófono
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 888)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 777 )//nuestros permisos
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            openCamera()
            }else{
                //el permiso no ha sido aceptado
                Toast.makeText(this,"Prmisos rechazados por primera vez",Toast.LENGTH_SHORT).show()

            }
        if (requestCode == 888)//nuestro segundo permiso
            if (grantResults.isNotEmpty()&& grantResults[1]== PackageManager.PERMISSION_GRANTED){
            openMic()
            }else{
                //permiso no aceptado
                Toast.makeText(this,"Prmisos rechazados por primera vez",Toast.LENGTH_SHORT).show()
            }

    }

}


